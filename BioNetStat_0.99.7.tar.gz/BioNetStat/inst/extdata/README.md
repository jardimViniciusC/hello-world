# Baixando os arquivos para o tutorial
Ao acessar o arquivo [bnsDataTest.csv](/data/bnsDataTest.csv) ou [c2.cp.v5.2.symbols.gmt](/data/c2.cp.v5.2.symbols.gmt) clique no botão 'raw' ou 'Download', para visualizar os arquivos em formato de texto.
Para salvar o arquivo, clique com o botão direito do mouse e selecione a opção 'slavar página como'. Escolha um diretório (pasta) e clique em salvar.

Pronto, o arquivo está salvo no seu computador.
